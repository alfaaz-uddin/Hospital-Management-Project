import java.lang.*;
  
  
public class Start {
		
	public static void main (String []args){
			
		UpPatient up = new UpPatient();
		up.setVisible(true);
		
			
	}
		
}
	
	