# Hospital-Management-Project
This is a Java project with the concept of Hospital Management System.
This project is made for the Object Oriented Programming-1 (Java) by the students of **American International University-Bangladesh (AIUB)**.
Team members are -  @*UDDIN, MD.ALFAZ, @SHAMIM, MD. SHAFAYAT HOSSAIN @RIYAD, KAZI FARDIN RAHMAN @DAS, ANIQUE KUMAR**
