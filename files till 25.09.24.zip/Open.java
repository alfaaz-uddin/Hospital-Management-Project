import java.lang.*;
  
	public class Open {
		
		public static void main (String []args){
			
			AddPatient ap = new AddPatient();
			ap.setVisible(true);
			
			
			
			
			
			
		}
		
	}
	
	