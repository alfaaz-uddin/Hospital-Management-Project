public class Patient extends Person {
	private int age;
	private String address;
    private String appointedDoctor;
    private String room;
    private String diagnosis;
	private double deposite;

    // Constructor
    public Patient( int age, String address; String appointedDoctor, String room, String diagnosis,double deposite) {
        super(id,name,mobileNo,gender);
		
		this.address = 	address;
        this.appointedDoctor = appointedDoctor;
        this.room = room;
        this.diagnosis = diagnosis;
		this.deposite = deposite;
    }

    // Getters and Setters
	
	public String getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
	
	
	
	
	public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
	
	
	
    public String getAppointedDoctor() {
        return appointedDoctor;
    }

    public void setAppointedDoctor(String appointedDoctor) {
        this.appointedDoctor = appointedDoctor;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }
	
	public double getDeposite() {
        return deposite;
    }

    public void setDeposite(double deposite) {
        this.deposite = deposite;
    }
	
	
	
	
}
 