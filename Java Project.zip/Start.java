import java.lang.*;
import Classes.*;
import Frames.*;
import Interfaces.*;

public class Start{
	public static void main(String []args){
		Login lg =  new Login();
		lg.setVisible(true);
	/*	Menu me =  new Menu();
		me.setVisible(true);*/
	}
}