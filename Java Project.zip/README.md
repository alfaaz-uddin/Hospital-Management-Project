# Hospital-Management-Project
This is a Java project with the concept of Hospital Management System.
This project was made for the course Object Oriented Programming-1 (Java) by the students of **American International University-Bangladesh (AIUB)** and guided by **UMME SADIA SALSABIL**, ***LECTURER,AIUB***.
Team members are -  @*UDDIN, MD.ALFAZ, @SHAMIM, MD. SHAFAYAT HOSSAIN @RIYAD, KAZI FARDIN RAHMAN @DAS, ANIQUE KUMAR**

In this  project -
*The admin can login and control the management system.
*Admin can add new patient, update 